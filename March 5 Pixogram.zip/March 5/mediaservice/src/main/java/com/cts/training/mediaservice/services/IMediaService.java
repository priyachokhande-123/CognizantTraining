package com.cts.training.mediaservice.services;

import java.util.List;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaUploadModel;




public interface IMediaService {


	List<Media> findAllMedias();
	Media findMediaById(Integer mediaId);
	boolean addMedia(Media media);
	boolean updateMedia(Media media);
	boolean deleteMedia(Integer mediaId);
	
	public void save(MediaData data);
	public void updateuser(MediaData data);

	
}

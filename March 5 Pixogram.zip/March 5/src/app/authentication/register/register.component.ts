import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UserRegistrationService } from 'src/app/services/user-registration.service';
import { Router } from '@angular/router';
import { UploadFileService } from 'src/app/services/upload-file.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { HttpEvent } from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  selectedFiles: FileList;
  currentFileUpload: File;
  username: string;
  password: string;
  email:string;
  fname:string;
  lname:string;
  date:Date;
  
  profilePic:string;
  ngOnInit(): void {
    this.username = this.auth.getUserDetails();
  }
 

  form: FormGroup;
 
 constructor( formBuilder: FormBuilder ,public userService:UserRegistrationService, public router: Router,public auth: AuthenticationService,
 public uploadFileService: UploadFileService
 ){ 
   this.form= formBuilder.group({
"userId":new FormControl(""),
"username":new FormControl(" ",Validators.required),
"password":new FormControl(" ",Validators.required),
"fname":new FormControl(" ",Validators.required),
"lname":new FormControl(" ",Validators.required),
"email":new FormControl(" ",Validators.required),
"profilePic":new FormControl(" ",Validators.required),
   });
 }
selectFile(event)
{
  this.selectedFiles= event.target.files;
}

  register(): void{

    this.username=this.form.get('username').value;
    this.password=this.form.get('password').value;
    this.email=this.form.get('email').value;
    this.fname=this.form.get('fname').value;
    this.lname=this.form.get('lname').value;
    
   this.currentFileUpload=this.selectedFiles.item(0);
    this.date = new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.currentFileUpload.type == 'image/png') {
      this.profilePic=`${this.username}${dateString}.png`;
    }
    if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
      this.profilePic =`${this.username}${dateString}.jpeg`;
    }


    this.uploadFileService.pushFileToStorage(this.currentFileUpload,this.profilePic,this.username,this.password,this.fname,this.lname,this.email,).subscribe((event:HttpEvent<{}>) => {
alert("registered Successfully");
this.login();
  
  })
}
  login():void{
    this.router.navigate(['login']);
  }
}
package com.cts.training.userservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.repository.UserDetailsRepository;
import com.cts.training.userservice.services.IUserService;
import com.cts.training.userservice.services.StorageService;

@RestController
public class UserController {


 private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private Environment env;
	// dependency
	@Autowired
	private IUserService userService;
	

	@Autowired
	private StorageService storageService;
	

	// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/users") // GET HTTP VERB
	public ResponseEntity<List<User>> exposeAll() {
		
		List<User> users = this.userService.findAllUsers();
		ResponseEntity<List<User>> response = 
								new ResponseEntity<List<User>>(users, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/users/{userId}") // GET HTTP VERB
	public ResponseEntity<User> getById(@PathVariable Integer userId) {
		
		User user = this.userService.findUserById(userId);
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	/*
	// @RequestMapping(value =  "/students", method = RequestMethod.POST)
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<User> save(@RequestBody User user) {
		this.userService.addUser(user);
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}


	*/
	
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<User> save(@RequestBody User user) {
		this.userService.addUser(user);
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/users")
	public ResponseEntity<User> saveUpdate(@RequestBody User user) {
		this.userService.updateUser(user);
			
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<User> delete(@PathVariable Integer userId) {
		
		User  user = this.userService.findUserById( userId);
		this.userService.deleteUser( userId);
		
		ResponseEntity<User> response = 
				new ResponseEntity<User>( user, HttpStatus.OK);

		return response;
	}
	
}

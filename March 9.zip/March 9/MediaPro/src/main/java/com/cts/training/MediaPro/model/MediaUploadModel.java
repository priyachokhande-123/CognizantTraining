package com.cts.training.MediaPro.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MediaUploadModel {

	private Integer userId;
	private String title;
	
	private String description;
	
  	private String fileUrl;
	
    private String mimeType;
	
	private String tags;
	
	
}

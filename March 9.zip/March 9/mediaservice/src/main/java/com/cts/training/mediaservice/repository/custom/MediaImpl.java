package com.cts.training.mediaservice.repository.custom;

public class MediaImpl {

}

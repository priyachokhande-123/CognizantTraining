package com.cts.training.mediaservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaUploadModel;
import com.cts.training.mediaservice.repository.MediaRepository;




//@Component
@Service
public class IMediaServiceImpl implements IMediaService {


	@Autowired
	private MediaRepository mediaRepository;
	
	@Override
	public List<Media> findAllMedias() {
		// add additional logic
		return this.mediaRepository.findAll();
	}
	
	@Override
	public Media findMediaById(Integer mediaId) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Media> record =  this.mediaRepository.findById(mediaId);
		// reduces the chance of NullException
		
		Media media=new Media();
		if(record.isPresent())
			media= record.get();
		return media;
		
	}

	@Override
	public boolean addMedia(Media media) {
		// TODO Auto-generated method stub
		this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean updateMedia(Media media) {
		// TODO Auto-generated method stub
		this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean deleteMedia(Integer mediaId) {
		// TODO Auto-generated method stub
		this.mediaRepository.deleteById(mediaId);
		return true;
	}



	@Override
	public void save(MediaUploadModel data) {
		// TODO Auto-generated method stub
		
		
		Media media=new Media();
		    media.setUserId(data.getUserId());
			media.setTitle(data.getTitle());
			media.setDescription(data.getDescription());
			media.setFileUrl(data.getFileUrl());
			media.setMimeType(data.getMimeType());
			media.setTags(data.getTags());
			this.mediaRepository.save(media);
		
	}

	public void updateuser(MediaData data) {
		Media media= new Media();
        media.setMediaId(data.getMediaId());
		media.setTitle(data.getTitle());
		media.setDescription(data.getDescription());
		media.setFileUrl(data.getFileUrl());
		media.setMimeType(data.getMimeType());
		media.setTags(data.getTags());
		this.mediaRepository.save(media);
		
		
	}

}
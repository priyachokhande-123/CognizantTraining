export class Media
{
//userId:number;   
mediaId: number;
title:string;
description:string;
tags:string;
fileUrl: string;




constructor(title:string,description:string, tags:string,fileUrl: string)
{
  // this.userId=userId;
   this.title=title;
   this.description=description;
   this.tags=tags;
   this.fileUrl=fileUrl;
}
}
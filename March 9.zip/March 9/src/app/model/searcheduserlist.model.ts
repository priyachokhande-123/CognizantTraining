import { SearchedUser } from "./searcheduser.model";

export class SearchedUserlList {

	userList : Array<SearchedUser>;
}
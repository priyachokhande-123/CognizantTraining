package com.cts.training.MediaPro.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.MediaPro.feignproxy.MediaServiceProxy;
import com.cts.training.MediaPro.model.MediaData;
import com.cts.training.MediaPro.model.MediaDataId;
import com.cts.training.MediaPro.model.MediaModel;
import com.cts.training.MediaPro.model.MediaUploadModel;


@RestController
@CrossOrigin("*")
public class MediaProController {

	@Autowired
	private MediaServiceProxy mediaServiceProxy;
	
	Logger logger=LoggerFactory.getLogger(this.getClass());
	
	

	@PostMapping("/media")
	public void post(@RequestParam("file") MultipartFile file,
			@RequestParam("userId") String userId,
			@RequestParam("title") String title,
			@RequestParam("description") String description,
			@RequestParam("fileUrl") String fileUrl,
			@RequestParam("mimetype") String mimeType,
		    @RequestParam("tags") String tags)
	{
		logger.info(tags);
		logger.info(fileUrl);
		logger.info(description);
		logger.info(title);
		logger.info(userId);
		MediaUploadModel model=new MediaUploadModel(Integer.parseInt(userId),title,description,fileUrl,mimeType,tags);
		this.mediaServiceProxy.saveData(model);

		this.mediaServiceProxy.save(file);
		
}
	
@GetMapping("/media/{userId}")
public ResponseEntity<List<MediaDataId>>userMedia(@PathVariable Integer userId)
{
ResponseEntity<List<MediaDataId>> response= this.mediaServiceProxy.findMediaByUserId(userId);
return response;
}

}

		
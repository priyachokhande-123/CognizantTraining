package com.cts.training.actionservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.repository.ActionRepository;


@Service
public class IActionImpl implements IActionService {



	@Autowired
	private ActionRepository actionRepository;
	
	@Override
	public List<Action> findAllActions() {
		// add additional logic
		return this.actionRepository.findAll();
	}
	
	@Override
	public Action findActionById(Integer actionId) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Action> record =  this.actionRepository.findById(actionId);
		// reduces the chance of NullException
		
		Action action=new Action();
		if(record.isPresent())
			action= record.get();
		return action;
		
	}

	@Override
	public boolean addAction(Action action) {
		// TODO Auto-generated method stub
		this.actionRepository.save(action);
		return true;
	}

	@Override
	public boolean updateAction(Action action) {
		// TODO Auto-generated method stub
		this.actionRepository.save(action);
		return true;
	}

	@Override
	public boolean deleteAction(Integer actionId) {
		// TODO Auto-generated method stub
		this.actionRepository.deleteById(actionId);
		return true;
	}




}

package com.cts.training.apigateway;



import java.util.Arrays;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	@Autowired
	private DataSource dataSource;
	
	// configure the credentials repository
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		
		/********** JDBC Authentication ***************/
		
		// default schema
		auth.jdbcAuthentication().dataSource(dataSource);
		
		// custom schema
		/*auth.jdbcAuthentication().dataSource(dataSource)
			.usersByUsernameQuery("")  // for reading username and password (authentication)
			.authoritiesByUsernameQuery(""); // for reading roles (authorazation)
		*/
		
	
	}
	
	// secure the application : define the accessibility rule
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
	http
		.cors()
		.and()
		.csrf().disable()
		.authorizeRequests()
		
		// .antMatchers("/user-service/**").hasRole("USER")
		.antMatchers("/user-service/login").hasRole("USER") //testing url for credentials
		//.antMatchers(HttpMethod.OPTIONS,"/login").hasAnyRole(new String[]{"USER","ADMIN","MANAGER"})
		//.antMatchers(HttpMethod.POST,"/api/**").hasRole("ADMIN")
		//.antMatchers(HttpMethod.GET,"/api/**").hasRole("USER")
	.and()
	.httpBasic();
	}
	
	@Bean
	CorsConfigurationSource corsConfigurationSource() 
	{
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("http://localhost:8761"));
		configuration.setAllowedMethods(Arrays.asList("GET","POST"));
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}


/***********
 * {bcrypt}$2a$04$ON6IrjLRg7WWRB5k/E8sfOvHwBiCz.8kmDTVywU/WUC5UZoJm0OiO
 */


package com.cts.training.blockeduserservice.repository.custom;

public class BlockedUsersImpl {

}

package com.cts.training.followservice.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FollowData {

	private Integer userId;
	private Integer followerId;
}

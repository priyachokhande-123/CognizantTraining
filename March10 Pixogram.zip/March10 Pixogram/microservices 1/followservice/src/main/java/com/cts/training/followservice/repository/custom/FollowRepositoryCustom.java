package com.cts.training.followservice.repository.custom;

public interface FollowRepositoryCustom {

}

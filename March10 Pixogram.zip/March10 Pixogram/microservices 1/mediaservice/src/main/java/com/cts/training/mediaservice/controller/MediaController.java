package com.cts.training.mediaservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaDataId;
import com.cts.training.mediaservice.model.MediaUploadModel;
import com.cts.training.mediaservice.services.IMediaService;
import com.cts.training.mediaservice.services.StorageService;

	@RestController
	public class MediaController {

		private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		
		@Autowired
		private IMediaService mediaService;
		
		@Autowired
		private StorageService storageService;

		@GetMapping("/media") // GET HTTP VERB
		public ResponseEntity<List<Media>> exposeAll() {
			
			List<Media> media= this.mediaService.findAllMedias();
			ResponseEntity<List<Media>> response = 
									new ResponseEntity<List<Media>>(media, HttpStatus.OK);
			
			
			return response;
		}
		
		@GetMapping("/media/user/{userId}") // GET HTTP VERB
		public ResponseEntity<List<MediaDataId>> getmediaByUserId(@PathVariable Integer userId) {
			List<MediaDataId> media=this.mediaService.findMediaByUserId(userId);
		
			ResponseEntity<List<MediaDataId>> response = 
					new ResponseEntity<List<MediaDataId>>(media,HttpStatus.OK);

			return response;
		}
		
		
		// {<data variable>}
		@GetMapping("/media/{mediaId}") // GET HTTP VERB
		public ResponseEntity<Media> getById(@PathVariable Integer mediaId) {
			
			Media media = this.mediaService.findMediaById(mediaId);
			ResponseEntity<Media> response = 
					new ResponseEntity<Media>(media, HttpStatus.OK);

			return response;
		}
		
		
		// @RequestMapping(value =  "/students", method = RequestMethod.POST)
		@PostMapping("/media") // POST HTTP VERB
		public ResponseEntity<Media> save(@RequestBody Media media) {
			this.mediaService.addMedia(media);
			ResponseEntity<Media> response = 
					new ResponseEntity<Media>(media, HttpStatus.OK);

			return response;
		}
		
		@PutMapping("/media")
		public ResponseEntity<Media> saveUpdate(@RequestBody Media media) {
			this.mediaService.updateMedia(media);
				
			ResponseEntity<Media> response = 
					new ResponseEntity<Media>(media, HttpStatus.OK);

			return response;
		}
		
		@DeleteMapping("/media/{mediaId}")
		public ResponseEntity<Media> delete(@PathVariable Integer mediaId) {
			
			Media  media = this.mediaService.findMediaById( mediaId);
			this.mediaService.deleteMedia( mediaId);
			
			ResponseEntity<Media> response = 
					new ResponseEntity<Media>( media, HttpStatus.OK);

			return response;
		
		}
	
		@PostMapping(value = "/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
		public boolean save(MultipartFile file) {
			this.storageService.store(file);
			return true;
		}


	// for saving media info in db
	@PostMapping(value = "/mediadata")
	public boolean saveData(@RequestBody MediaUploadModel media) {
		/*MediaData media1 = new MediaData();
		
		medial.setUserId(media.getUserId());
		medial.setTitle(media.getTitle());
		media1.setDescription(media.getDescription());
		media1.setFileUrl(media.getFileUrl());
		media1.setMimeType(media.getMimeType());
		media1.setTags(media.getTags());*/
	
		this.mediaService.save(media);
	
		return true;
	}

	

		

		
	
		
	}

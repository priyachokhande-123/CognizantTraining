package com.cts.training.mediaservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MediaDataId {


	private Integer userId;
	private String title;
	
	private String description;
	
  	private String fileUrl;
	
    private String mimeType;
	
	private String tags;
	
}



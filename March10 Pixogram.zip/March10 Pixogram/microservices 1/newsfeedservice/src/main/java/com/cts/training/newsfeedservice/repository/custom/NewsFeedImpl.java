package com.cts.training.newsfeedservice.repository.custom;

public class NewsFeedImpl {

}

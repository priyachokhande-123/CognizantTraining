package com.cts.training.newsfeedservice.repository.custom;

public interface NewsFeedRepositoryCustom {

}

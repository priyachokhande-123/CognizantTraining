import { Component, OnInit } from '@angular/core';
import { SingleMedia } from '../media-list/singlemedia.model';
import { Router } from '@angular/router';
import { SinglemediaService } from 'src/app/services/singlemedia.service';

@Component({
  selector: 'app-media-details',
  templateUrl: './media-details.component.html',
  styleUrls: ['./media-details.component.css']
})
export class MediaDetailsComponent implements OnInit {
medias: SingleMedia[];

  constructor(public singlemediaService:SinglemediaService ,private  router:Router) { }

  ngOnInit() {
this.singlemediaService.getAllSingleMedia().subscribe(data=>{
this.medias=data;
console.log(this.medias);
for(let media of this.medias)
{
  media.fileUrl="http://localhost:8765/media-service/"+media.fileUrl
}

})

  }

}

export class SingleMedia
{
    userId: number;
    title:string;
    description:string;
    fileUrl: string;
    mimeType :string;
    tags:String 
}



	
	
	
  	
	
 
	

	
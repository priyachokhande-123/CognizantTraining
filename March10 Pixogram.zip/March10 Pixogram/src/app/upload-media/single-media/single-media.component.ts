import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Media } from 'src/app/model/media.model';
import { MediaServiceService } from 'src/app/services/media-service.service';
import { HttpEvent } from '@angular/common/http';
import { AuthenticationService } from 'src/app/services/authentication.service';


@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {
 
  ngOnInit(): void {
   this.userId=this.auth.getUserId();
  }
  

  
 

  
title : string;
description:string;
tags:string;
fileUrl: string;
myFormGroup : FormGroup;
selectedFiles: FileList;
currentFileUpload : File;
date : Date;
userId:string;

constructor(public formBuilder: FormBuilder, public mediaService : MediaServiceService,public router : Router ,public auth : AuthenticationService ) {
  console.log("in form bilder of single media");
  this.myFormGroup=formBuilder.group({
    "title":new FormControl("",Validators.required),
    "description":new FormControl(""),
    "tags":new FormControl("")
  });

}

selectFile(event){
this.selectedFiles = event.target.files;

}

upload():void{
 
  this.title= this.myFormGroup.controls['title'].value;
  this.description=this.myFormGroup.controls['description'].value;
  this.tags=this.myFormGroup.controls['tags'].value;
  this.date=new Date();
  this.currentFileUpload=this.selectedFiles.item(0);
  let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
  if (this.currentFileUpload.type == 'image/png') {
    this.fileUrl = `${this.title}${dateString}.png`;
  }
  if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
    this.fileUrl= `${this.title}${dateString}.jpeg`;
  }


  this.mediaService.pushFileToStorage(this.currentFileUpload,this.title,this.description,this.fileUrl,this.tags,this.currentFileUpload.type).subscribe((event:HttpEvent<{}>) => {
    // alert("media uploaded Successfully");
    
     this.router.navigate(['/media/'])
  })
  
  
}

}

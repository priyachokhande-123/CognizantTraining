package com.cts.training.followservice.repository.custom;

public class FollowImpl {

}

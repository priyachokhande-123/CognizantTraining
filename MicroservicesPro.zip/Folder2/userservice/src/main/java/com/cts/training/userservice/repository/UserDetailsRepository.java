package com.cts.training.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.userservice.entity.UserDetails;
import com.cts.training.userservice.repository.custom.UserDetailsRepositoryCustom;


@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, Integer> ,UserDetailsRepositoryCustom   {

}

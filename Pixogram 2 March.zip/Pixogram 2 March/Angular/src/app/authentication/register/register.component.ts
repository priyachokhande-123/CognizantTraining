import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UserRegistrationService } from 'src/app/services/user-registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 

  form: FormGroup;
 
 constructor( formBuilder: FormBuilder ,public userService:UserRegistrationService, public router: Router)

 { 
   this.form= formBuilder.group({
"userId":new FormControl(""),
"username":new FormControl(" ",Validators.required),
"password":new FormControl(" ",Validators.required),
"fname":new FormControl(" ",Validators.required),
"lname":new FormControl(" ",Validators.required),
"email":new FormControl(" ",Validators.required),
"profilePic":new FormControl(" ",Validators.required),
   });
 }
  register(): void{
    this.userService.addNewUser(this.form.value).subscribe(data=>{
alert("registered Successfully");
this.login();
    })
  }
  login():void{
    this.router.navigate(['login']);
  }

/*
  onSubmit(){
    alert(this.form.get("userame").value);
    alert(this.form.get("fname").value);
    alert(this.form.get("lname").value);
    alert(this.form.get("email").value);
    alert(this.form.get("profilePic").value);
  }
  */

  ngOnInit(): void {
    
  }
}

  
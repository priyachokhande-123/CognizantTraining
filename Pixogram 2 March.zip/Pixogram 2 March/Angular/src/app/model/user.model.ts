export class User{
    userId: number;
    file : File;
    url : string;
    userName:string;
    fname : string;
    lname:string;
    email:string;

    constructor(userName:string, fname:string,lname:string,email:string, file:File, url : string ){
       this.userName=userName;
       this.fname=fname;
       this.lname=lname;
       this.email=email;
        this.file = file;
        this.url = url;
    }
}
package com.cts.training.blockeduserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockeduserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockeduserserviceApplication.class, args);
	}

}

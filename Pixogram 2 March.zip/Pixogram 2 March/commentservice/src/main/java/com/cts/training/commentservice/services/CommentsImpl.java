package com.cts.training.commentservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.commentservice.entity.Comments;
import com.cts.training.commentservice.repository.CommentsRepository;



@Service
public class CommentsImpl implements ICommentService{



	@Autowired
	private CommentsRepository commentsRepository;
	
	@Override
	public List<Comments> findAllComments() {
		// add additional logic
		return this.commentsRepository.findAll();
	}
	
	@Override
	public Comments findCommentById(Integer commentId) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Comments> record =  this.commentsRepository.findById(commentId);
		// reduces the chance of NullException
		
		Comments comment=new Comments();
		if(record.isPresent())
			comment= record.get();
		return comment;
		
	}

	@Override
	public boolean addComment(Comments comment) {
		// TODO Auto-generated method stub
		this.commentsRepository.save(comment);
		return true;
	}

	@Override
	public boolean updateComment(Comments comment) {
		// TODO Auto-generated method stub
		this.commentsRepository.save(comment);
		return true;
	}

	@Override
	public boolean deleteComment(Integer commentId) {
		// TODO Auto-generated method stub
		this.commentsRepository.deleteById(commentId);
		return true;
	}


}

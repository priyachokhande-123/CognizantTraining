package com.cts.training.newsfeedservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeedservice.repository.NewsFeedRepository;



@Service
public class NewsFeedImpl implements INewsfeedService{


	@Autowired
	private NewsFeedRepository newsFeedRepository ;
	
	

	@Override
	public List<NewsFeed> findAllNewsFeeds() {
		// add additional logic
		return this.newsFeedRepository.findAll();
	}
	
	@Override
	public NewsFeed findNewsFeedById(Integer newsFeedId) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<NewsFeed> record =  this.newsFeedRepository.findById(newsFeedId);
		// reduces the chance of NullException
		
		NewsFeed newsFeed=new NewsFeed();
		if(record.isPresent())
			newsFeed= record.get();
		return newsFeed;
		
	}

	@Override
	public boolean addNewsFeed(NewsFeed newsFeed) {
		// TODO Auto-generated method stub
		this.newsFeedRepository.save(newsFeed);
		return true;
	}

	@Override
	public boolean updateNewsFeed(NewsFeed newsFeed) {
		// TODO Auto-generated method stub
		this.newsFeedRepository .save(newsFeed);
		return true;
	}

	@Override
	public boolean deleteNewsFeed(Integer newsFeedId) {
		// TODO Auto-generated method stub
		this.newsFeedRepository .deleteById(newsFeedId);
		return true;
	}


}

package com.cts.training.userservice.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserModel implements Serializable{


	private Integer userId;
	private String username;
	private String fname;
	private String lname;
	private MultipartFile file;
	private String email;
	
	private String url;
	public String getUserName() {
		return username;
	}
}



package com.cts.training.actionservice.services;

import java.util.List;

import com.cts.training.actionservice.entity.Action;

public interface IActionService {


	List<Action> findAllActions();
	Action findActionById(Integer actionId);
	boolean addAction(Action action);
	boolean updateAction(Action action);
	boolean deleteAction(Integer actionId);
}

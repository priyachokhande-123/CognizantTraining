package com.cts.training.blockeduserservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.blockeduserservice.entity.BlockedUsers;
import com.cts.training.blockeduserservice.repository.custom.BlockedUsersRepositoryCustom;




public interface BlockedUsersRepository extends JpaRepository<BlockedUsers, Integer> ,BlockedUsersRepositoryCustom   {

}

package com.cts.training.commentservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.commentservice.entity.Comments;

import com.cts.training.commentservice.services.ICommentService;




@RestController

public class CommentController {

	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		@Autowired
		private ICommentService commentService;
	


		@GetMapping("/comment") // GET HTTP VERB
		public ResponseEntity<List<Comments>> exposeAll() {
			
			List<Comments> comment= this.commentService.findAllComments();
			ResponseEntity<List<Comments>> response = 
									new ResponseEntity<List<Comments>>(comment, HttpStatus.OK);
			
			
			return response;
		}
		
		// {<data variable>}
		@GetMapping("/comment/{commentId}") // GET HTTP VERB
		public ResponseEntity<Comments> getById(@PathVariable Integer commentId) {
			
			Comments comment = this.commentService.findCommentById(commentId);
			ResponseEntity<Comments> response = 
					new ResponseEntity<Comments>(comment, HttpStatus.OK);

			return response;
		}
		
		// @RequestMapping(value =  "/students", method = RequestMethod.POST)
		@PostMapping("/comment") // POST HTTP VERB
		public ResponseEntity<Comments> save(@RequestBody Comments comment) {
			this.commentService.addComment(comment);
			ResponseEntity<Comments> response = 
					new ResponseEntity<Comments>(comment, HttpStatus.OK);

			return response;
		}
		
		@PutMapping("/comment")
		public ResponseEntity<Comments> saveUpdate(@RequestBody Comments comment) {
			this.commentService.updateComment(comment);
				
			ResponseEntity<Comments> response = 
					new ResponseEntity<Comments>(comment, HttpStatus.OK);

			return response;
		}
		
		@DeleteMapping("/comment/{commentId}")
		public ResponseEntity<Comments> delete(@PathVariable Integer commentId) {
			
			Comments  comment = this.commentService.findCommentById( commentId);
			this.commentService.deleteComment( commentId);
			
			ResponseEntity<Comments> response = 
					new ResponseEntity<Comments>( comment, HttpStatus.OK);

			return response;
		}
}



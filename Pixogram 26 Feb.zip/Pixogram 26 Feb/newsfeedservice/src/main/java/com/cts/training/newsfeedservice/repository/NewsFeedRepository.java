package com.cts.training.newsfeedservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeedservice.repository.custom.NewsFeedRepositoryCustom;



@Repository
public interface NewsFeedRepository extends JpaRepository<NewsFeed, Integer> ,NewsFeedRepositoryCustom   {

}

import { Injectable } from '@angular/core';

import { HttpHeaders,  HttpClient } from '@angular/common/http';

import {map} from 'rxjs/operators';

const VALIDATION_URL = "http://localhost:8765/user-service/login";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(public http : HttpClient )  { }
/*
  authenticate(userid : string, password : string): boolean{
   
    if(userid === "First" && password === "abc"){
    
      sessionStorage.setItem("user", userid);
      return true;
    }else{
      return false;
    }
  }
  */

  authenticate(userId : string, password : string){
    // create a security token
    let authenticationToken = "Basic " + window.btoa(userId + ":" + password);
    console.log(authenticationToken);

    let headers = new HttpHeaders({
      Authorization : authenticationToken
      
    });

    // send the request
    return this.http.get(VALIDATION_URL, {headers}).pipe(
      // success function
      map(successData=>{
        sessionStorage.setItem("user", userId);
        // save the token
        sessionStorage.setItem("token", authenticationToken);
        return successData;
      }),
      // failure function
      map(failureData=>{
        // console message 
        return failureData;
      })
    );
  }

  // method to get the token
  getAuthenticationToken(){
    if(this.isUserLoggedIn())
      return sessionStorage.getItem("token");
    return null; 
  }


  isUserLoggedIn(): boolean{
  
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    return true;  
  }


  logout(){
  
    sessionStorage.removeItem('user');
   
  }
  /*
  signup()
  {
    this.router.navigate(['/signup']);
  }
  */

  getUserDetails():string{
    let user = sessionStorage.getItem('user');
    return user;
  }


}

package com.cts.training.userservice.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserInput {

	private String username;
	private String password;
	private String fname;
	private String lname;
	private String email;
	private String profilePic;
	
}

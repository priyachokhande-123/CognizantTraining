package com.cts.training.blockeduserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockeduserserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

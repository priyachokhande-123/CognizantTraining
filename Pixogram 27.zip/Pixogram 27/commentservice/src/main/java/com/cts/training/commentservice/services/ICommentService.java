package com.cts.training.commentservice.services;

import java.util.List;

import com.cts.training.commentservice.entity.Comments;


public interface ICommentService {


	List<Comments> findAllComments();
	Comments findCommentById(Integer CommentId);
	boolean addComment(Comments comment);
	boolean updateComment(Comments comment);
	boolean deleteComment(Integer CommentId);
}

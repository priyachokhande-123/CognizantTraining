package com.cts.training.userservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.userservice.model.ResponseData;
import com.cts.training.userservice.model.UserInput;
import com.cts.training.userservice.services.IUserService;




@RestController
// @CrossOrigin("*")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders="*")
public class LoginController {
	
	@Autowired
	private IUserService userService;
	
	private Logger logger=LoggerFactory.getLogger(this.getClass());
	//whether this testing url for testing our credentials is called or not
	@GetMapping("/login")
	public ResponseEntity<ResponseData>  login()
	{
		logger.info("Logged in..");
		

		ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis());

		final MultiValueMap<String, String> header = new LinkedMultiValueMap<String, String>();
		header.add("", "");
		ResponseEntity<ResponseData> response = 
					new ResponseEntity<ResponseData>(data, HttpStatus.OK);
		
		
		
		return response;
		

	}
	@PostMapping("/register")
	public ResponseEntity<ResponseData>  register(@RequestBody UserInput userInput)
	{
		logger.info("Registration..");
		logger.info("User Input : " + userInput);
		this.userService.saveuser(userInput);
		
		

		ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis());

		ResponseEntity<ResponseData> response = 
					new ResponseEntity<ResponseData>(data, HttpStatus.OK);
		
		
		
		return response;
		

	}
}

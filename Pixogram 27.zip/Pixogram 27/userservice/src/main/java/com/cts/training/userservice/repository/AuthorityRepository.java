package com.cts.training.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.userservice.entity.Roles;
import com.cts.training.userservice.repository.custom.AuthorityRepositoryCustom;


@Repository
public interface AuthorityRepository{
	public void  save (Roles role);
}

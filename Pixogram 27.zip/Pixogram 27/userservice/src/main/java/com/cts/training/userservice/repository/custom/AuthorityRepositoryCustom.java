package com.cts.training.userservice.repository.custom;

public interface AuthorityRepositoryCustom {

}

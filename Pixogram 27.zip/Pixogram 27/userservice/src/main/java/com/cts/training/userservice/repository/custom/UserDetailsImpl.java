package com.cts.training.userservice.repository.custom;

public class UserDetailsImpl {

}

package com.cts.training.actionservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.repository.custom.ActionRepositoryCustom;




public interface ActionRepository extends JpaRepository<Action, Integer>,ActionRepositoryCustom   {

}

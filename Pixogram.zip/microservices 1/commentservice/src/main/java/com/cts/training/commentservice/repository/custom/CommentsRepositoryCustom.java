package com.cts.training.commentservice.repository.custom;

public interface CommentsRepositoryCustom {

}

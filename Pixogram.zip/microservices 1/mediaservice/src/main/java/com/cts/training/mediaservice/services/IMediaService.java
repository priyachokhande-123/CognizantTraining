package com.cts.training.mediaservice.services;

import java.util.List;

import com.cts.training.mediaservice.entity.Media;


public interface IMediaService {


	List<Media> findAllMedias();
	Media findMediaById(Integer mediaId);
	boolean addMedia(Media media);
	boolean updateMedia(Media media);
	boolean deleteMedia(Integer mediaId);
}

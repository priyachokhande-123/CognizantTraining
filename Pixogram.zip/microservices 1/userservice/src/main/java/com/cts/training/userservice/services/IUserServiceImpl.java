package com.cts.training.userservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.repository.UserDetailsRepository;

//@Component
	@Service
public class IUserServiceImpl implements IUserService{ 

		

		@Autowired
		private UserDetailsRepository userRepository;
		
		@Override
		public List<User> findAllUsers() {
			// add additional logic
			return this.userRepository.findAll();
		}
		
		@Override
		public User findUserById(Integer userId) {
			// TODO Auto-generated method stub
			// resolves problem of null reference exception
			Optional<User> record =  this.userRepository.findById(userId);
			// reduces the chance of NullException
			
			User user=new User();
			if(record.isPresent())
				user= record.get();
			return user;
			
		}

		@Override
		public boolean addUser(User user) {
			// TODO Auto-generated method stub
			this.userRepository.save(user);
			return true;
		}

		@Override
		public boolean updateUser(User user) {
			// TODO Auto-generated method stub
			this.userRepository.save(user);
			return true;
		}

		@Override
		public boolean deleteUser(Integer userId) {
			// TODO Auto-generated method stub
			this.userRepository.deleteById(userId);
			return true;
		}

	

	



}

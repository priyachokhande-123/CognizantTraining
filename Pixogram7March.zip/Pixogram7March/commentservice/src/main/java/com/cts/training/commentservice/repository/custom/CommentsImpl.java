package com.cts.training.commentservice.repository.custom;

public class CommentsImpl {

}

package com.cts.training.newsfeedservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeedservice.repository.NewsFeedRepository;
import com.cts.training.newsfeedservice.services.INewsfeedService;



@RestController
public class NewsFeedController {

		private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
	
		@Autowired
		private INewsfeedService newsFeedService;
	
		

		@GetMapping("/newsFeed") // GET HTTP VERB
		public ResponseEntity<List<NewsFeed>> exposeAll() {
			
			List<NewsFeed> newsFeed= this.newsFeedService.findAllNewsFeeds();
			ResponseEntity<List<NewsFeed>> response = 
									new ResponseEntity<List<NewsFeed>>(newsFeed, HttpStatus.OK);
			
			
			return response;
		}
		
		// {<data variable>}
		@GetMapping("/newsFeed/{newsFeedId}") // GET HTTP VERB
		public ResponseEntity<NewsFeed> getById(@PathVariable Integer newsFeedId) {
			
			NewsFeed newsFeed = this.newsFeedService.findNewsFeedById(newsFeedId);
			ResponseEntity<NewsFeed> response = 
					new ResponseEntity<NewsFeed>(newsFeed, HttpStatus.OK);

			return response;
		}
		
		// @RequestMapping(value =  "/students", method = RequestMethod.POST)
		@PostMapping("/newsFeed") // POST HTTP VERB
		public ResponseEntity<NewsFeed> save(@RequestBody NewsFeed newsFeed) {
			this.newsFeedService.addNewsFeed(newsFeed);
			ResponseEntity<NewsFeed> response = 
					new ResponseEntity<NewsFeed>(newsFeed, HttpStatus.OK);

			return response;
		}
		
		@PutMapping("/newsFeed")
		public ResponseEntity<NewsFeed> saveUpdate(@RequestBody NewsFeed newsFeed) {
			this.newsFeedService.updateNewsFeed(newsFeed);
				
			ResponseEntity<NewsFeed> response = 
					new ResponseEntity<NewsFeed>(newsFeed, HttpStatus.OK);

			return response;
		}
		
		@DeleteMapping("/newsFeed/{newsFeedId}")
		public ResponseEntity<NewsFeed> delete(@PathVariable Integer newsFeedId) {
			
			NewsFeed  newsFeed = this.newsFeedService.findNewsFeedById( newsFeedId);
			this.newsFeedService.deleteNewsFeed( newsFeedId);
			
			ResponseEntity<NewsFeed> response = 
					new ResponseEntity<NewsFeed>( newsFeed, HttpStatus.OK);

			return response;
		}
	}



package com.cts.training.newsfeedservice.services;

import java.util.List;

import com.cts.training.newsfeedservice.entity.NewsFeed;


public interface INewsfeedService {


	List<NewsFeed> findAllNewsFeeds();
	NewsFeed findNewsFeedById(Integer newsFeedId);
	boolean addNewsFeed(NewsFeed newsFeed);
	boolean updateNewsFeed(NewsFeed  newsFeed);
	boolean deleteNewsFeed(Integer  newsFeedId);
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

const BasicURL = "http://localhost:3000/mediafiles";
@Injectable({
  providedIn: 'root'
})
export class MediaServiceService {
    baseUrl: string = 'http://localhost:8765/MediaPro-service/media';

    constructor(public http : HttpClient ) { }

    
  getAllMedia():any{
    return this.http.get(BasicURL);
  }

  getMedia(id:number):any{
    return this.http.get(BasicURL+"/"+id);
  }
  
  pushFileToStorage(file: File,title,description,tags,url,mimetype) : Observable<HttpEvent<{}>>{
    
    const formdata: FormData = new FormData();


 console.log("userId in media : "+sessionStorage.getItem("userId"))
    formdata.append('userId',sessionStorage.getItem("userId"))
    formdata.append('title',title)
    formdata.append('description',description)
    formdata.append('file', file, url);
   formdata.append('mimetype',mimetype)
   
    formdata.append("tags",tags)
    formdata.append('fileUrl',url)
    


    const req = new HttpRequest('POST', `${this.baseUrl}`, formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }
}






 
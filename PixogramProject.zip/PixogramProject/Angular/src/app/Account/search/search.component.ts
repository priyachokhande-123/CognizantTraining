import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { SearchedUser } from 'src/app/model/searcheduser.model';
import { Router } from '@angular/router';
import { SearchedUserlList } from 'src/app/model/searcheduserlist.model';
import { UserRegistrationService } from 'src/app/services/user-registration.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  userList : Array<SearchedUser>;

  constructor(formbuilder : FormBuilder, public router: Router, private userService: UserRegistrationService ) {
    
    this.myFormGroup = formbuilder.group(
      {
        "keyword" : new FormControl(),
      }
    );

   }

   search(){
     this.searchtext = this.myFormGroup.controls['keyword'].value;
     this.userService.getSearchedUsers(this.searchtext).subscribe(
      (response : SearchedUserlList) => {
        this.userList = response.userList;
        this.userList = this.userList.map(user =>{
          user.profilePic = "http://localhost:8765/user-service/"+user.profilePic;
          return user;
        });
        
      }
    );
   }

   

  ngOnInit() {
  }

}

export class SingleMedia
{
    mediaId:number;
    userId: number;
    title:string;
    description:string;
    fileUrl: string;
    mimeType :string;
    tags:String ;
    likes:number;
    disLikes:number;
    commentCount:number;

}



	
	
	
  	
	
 
	

	
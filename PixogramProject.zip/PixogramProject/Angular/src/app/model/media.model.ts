export class Media
{
//userId:number;   
mediaId: number;
title:string;
description:string;
fileUrl: string;
tags:string;



constructor(title:string,description:string, tags:string,fileUrl: string)
{
  // this.userId=userId;
   this.title=title;
   this.description=description;
 
   this.fileUrl=fileUrl;
   this.tags=tags;
}
}
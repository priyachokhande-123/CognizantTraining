export class SearchedUser {
	userId : number;
	name : string;
	profilePic : string;
	followed : boolean;
}
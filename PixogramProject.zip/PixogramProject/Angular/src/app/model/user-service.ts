export class UserRegistrationDetails
{

    userId:number;
    username:string;
    password:string;
    fname:string;
    lname:string;
    email:string;
    profilePic:string;

    
    constructor(
        username:string,
        password:string,
        fname:string,
        lname:string,
        email:string,
        profilePic:string,
    )
    {
this.username=username;
this.password=password;
this.email=email;
this.fname=fname;
this.lname=lname;
this.email=email;
this.profilePic=profilePic;
    }

}
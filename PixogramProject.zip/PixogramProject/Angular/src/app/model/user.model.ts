export class User{
    userId: number;
    username:string;
    password:string;
    email:string;
    fname : string;
    lname:string;
    file : File;
    ProfilePic:string;

 
   

    constructor(username:string, fname:string, password:string,lname:string,email:string, file:File,  ProfilePic:string){
       this.username=username;
       this.password=password;
       this.fname=fname;
       this.lname=lname;
       this.email=email;
        this.file = file;
        this.ProfilePic=ProfilePic;
        
    }
}
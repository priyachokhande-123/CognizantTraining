import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  baseUrl: string = 'http://localhost:8765/user-service/register ';

  constructor(private http: HttpClient, public auth : AuthenticationService) { }

  pushFileToStorage(file: File, profilePic, username,password,fname,lname, email) : Observable<HttpEvent<{}>>{
    
    const formdata: FormData = new FormData();

    // let product = new  Product (name,category,cost,file,url);
   
    formdata.append('file',file,profilePic);
    formdata.append('profilePic',profilePic);
    formdata.append('username',username);
    formdata.append('password',password);
    formdata.append('fname',fname);
    formdata.append('lname',lname);
    formdata.append('email',email);
   

    // header info to set for responding the progress report
    /*return this.http.post(this.baseUrl, formdata,{
      reportProgress: true,
      responseType: 'text'
    });*/

    const req = new HttpRequest('POST', `${this.baseUrl}`, formdata);

    return this.http.request(req);
  }

 
}
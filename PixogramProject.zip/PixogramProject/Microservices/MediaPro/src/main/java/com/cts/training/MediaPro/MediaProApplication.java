package com.cts.training.MediaPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;


@SpringBootApplication
// enable to use the feign client : allow feign to connect to Microservices
// @EnableFeignClients(<package where proxy interaface are>)
@EnableFeignClients("com.cts.training.MediaPro.feignproxy")
// enable/register as eureka client
@EnableEurekaClient

public class MediaProApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaProApplication.class, args);
	}

}

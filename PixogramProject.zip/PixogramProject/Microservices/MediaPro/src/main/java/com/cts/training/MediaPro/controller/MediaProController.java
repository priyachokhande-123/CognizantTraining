package com.cts.training.MediaPro.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.MediaPro.feignproxy.ActionServiceProxy;
import com.cts.training.MediaPro.feignproxy.CommentServiceProxy;
import com.cts.training.MediaPro.feignproxy.MediaServiceProxy;
import com.cts.training.MediaPro.model.ActionDataModel;
import com.cts.training.MediaPro.model.CommentsNumberModel;
import com.cts.training.MediaPro.model.CountOfActionsModel;
import com.cts.training.MediaPro.model.LikesAndDislikesModel;
import com.cts.training.MediaPro.model.MediaActionModel;
import com.cts.training.MediaPro.model.MediaDataId;
import com.cts.training.MediaPro.model.MediaUploadModel;


@RestController
@CrossOrigin("*")
public class MediaProController {

	@Autowired
	private MediaServiceProxy mediaServiceProxy;
	

	@Autowired
	private CommentServiceProxy commentServiceProxy;

	@Autowired
	private ActionServiceProxy actionServiceProxy;
	
	Logger logger=LoggerFactory.getLogger(this.getClass());
	
	

	@PostMapping("/media")
	public void post(@RequestParam("file") MultipartFile file,
			@RequestParam("userId") String userId,
			@RequestParam("title") String title,
			@RequestParam("description") String description,
			@RequestParam("fileUrl") String fileUrl,
			@RequestParam("mimetype") String mimeType,
		    @RequestParam("tags") String tags)
	{
		logger.info(tags);
		logger.info(fileUrl);
		logger.info(description);
		logger.info(title);
		logger.info(userId);
		MediaUploadModel model=new MediaUploadModel(Integer.parseInt(userId),title,description,fileUrl,mimeType,tags);
		this.mediaServiceProxy.saveData(model);

		this.mediaServiceProxy.save(file);
		
}
	
	
@GetMapping("/media/{userId}")
public ResponseEntity<List< MediaActionModel>> userMedia(@PathVariable Integer userId)
{
List<MediaDataId> response= this.mediaServiceProxy.findMediaByUserId(userId).getBody();
   List<MediaActionModel> ladm=response.stream().map(res->{
	   Integer likes,dislikes,comments;
	   
	   try {
		   CommentsNumberModel cnm=this.commentServiceProxy.getCountById(res.getMediaId()).getBody();
		   comments = cnm.getComments();
		   

	}
		   catch(Exception e) {
			   comments = 0;
	}
	   
	   try {
		   CountOfActionsModel cam=this.actionServiceProxy.getLikes(res.getMediaId()).getBody();
		   likes = cam.getLikes();
		   dislikes = cam.getDisLikes();

	}
		   catch(Exception e) {
			   likes = 0;
			   dislikes = 0;
	}
  
	 
	   MediaActionModel adm=new MediaActionModel(res.getMediaId(),res.getUserId(),res.getTitle(),res.getDescription(),res.getFileUrl(),res.getMimeType(),res.getTags(),likes,dislikes,comments);
	   return adm;
   }).collect(Collectors.toList());
   
   ResponseEntity<List< MediaActionModel>> result=new ResponseEntity<List< MediaActionModel>>(ladm,HttpStatus.OK);
   return result;

}

	
/*
	@GetMapping("/media/{userId}")
	public ResponseEntity<MediaDetailsModel> getAllById(@PathVariable Integer userId){
		
		ResponseEntity<MediaModelList> media = this.mediaServiceProxy.(userId);
		
		List<GallaryResponse> filelist = new ArrayList<GallaryResponse>();
		
		logger.info("user id : => : "+userId);
		logger.info("List : " + media.getBody().getMedialist());
		for(MediaData data : media.getBody().getMedialist()) {	
			logger.info("ID :" + data.getMediaId());
			
			CommentsNumberModel commentsCount =  this.commentServiceProxy.getCountById(data.getId()).getBody();
			
			Integer cmts = 0;
			if(commentsCount !=null) {
				cmts = commentsCount.getComments();
			}
			Integer likes = this.actionServiceProxy.getLikesAndDislikes(data.getMediaId()).getBody().getLikes();
			Integer disLikes = this.actionServiceProxy.getLikesAndDislikes(data.getMediaId()).getBody().getDisLikes();
			//CommentNumberModel commentNumberModel = this.commentServiceProxy.getCountById(data.getId()).getBody();
			//System.out.println(commentNumberModel.getComments());
			
			GallaryResponse response = new GalleryResponse(data.getMediaId(), data.getUserId(), data.getTitle(), data.getDescription(), data.getTags(), data.getType(), data.getUrl(),cmts,likes,disLikes);
			filelist.add(response);
		}
		
		MediaDetailsModel resultlist = new MediaDetailsModel();
		resultlist.setFilelist(filelist);
		ResponseEntity<MediaDetailsModel> result = new ResponseEntity<MediaDetailsModel>(resultlist,HttpStatus.OK);	
		
		return result;
	}
	
	
	
	@GetMapping("/comment/{id}")
	public ResponseEntity<CommentsNumberModel> getCommentsCount(@PathVariable Integer id){
		ResponseEntity<CommentsNumberModel> count = this.commentServiceProxy.getCountById(id);
		return count;
	}
*/

}

		
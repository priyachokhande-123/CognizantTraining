package com.cts.training.MediaPro.feignproxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.training.MediaPro.model.CountOfActionsModel;



@FeignClient(name="api-gateway",url="http://localhost:8765")
@RibbonClient(name="action-service")
@Service

public interface ActionServiceProxy {

	@GetMapping("/action-service/getlikes/{mediaId}")
	public ResponseEntity<CountOfActionsModel> getLikes(@PathVariable Integer mediaId);
	

	
}



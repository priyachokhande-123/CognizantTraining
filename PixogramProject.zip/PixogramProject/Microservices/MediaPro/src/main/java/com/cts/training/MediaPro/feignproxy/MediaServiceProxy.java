package com.cts.training.MediaPro.feignproxy;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.MediaPro.model.MediaDataId;
import com.cts.training.MediaPro.model.MediaUploadModel;



@FeignClient(name = "api-gateway", url="http://localhost:8765") // path is managed by server
// configure the Ribbon to load balance
@RibbonClient(name = "media-service") // will activate load balancing on media-service
@Service
public interface MediaServiceProxy {


	
	@PostMapping(value = "/media-service/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file);


// for saving media info in db
@PostMapping(value = "/media-service/mediadata")
public boolean saveData(@RequestBody MediaUploadModel media);
	
@GetMapping(value="/media-service/media/user/{userId}")
public ResponseEntity<List<MediaDataId>> findMediaByUserId(@PathVariable Integer userId);
}

	
	
	
	
	
	


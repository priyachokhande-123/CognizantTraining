package com.cts.training.MediaPro.model;

import java.util.List;

import com.cts.training.MediaPro.GallaryResponse.GallaryResponse;



import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MediaDetailsModel {
	private List<GallaryResponse> filelist;

	
}

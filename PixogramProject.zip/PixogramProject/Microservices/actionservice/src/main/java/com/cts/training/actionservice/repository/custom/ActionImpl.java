package com.cts.training.actionservice.repository.custom;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.training.actionservice.model.CountOfActionsModel;

public class ActionImpl implements ActionRepositoryCustom {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private EntityManager entityManager;


	
	@Override
	public CountOfActionsModel findLikesModelDislikesModelByMediaId(Integer mediaId) {
												 					
		TypedQuery<Long> likesQuery = entityManager.createQuery("SELECT COUNT(*) FROM Action a WHERE a.mediaId=:mediaId AND a.status=true",Long.class);
		
		likesQuery.setParameter("mediaId", mediaId);
		
		TypedQuery<Long> disLikesQuery = entityManager.createQuery("SELECT COUNT(*) FROM Action a WHERE a.mediaId=:mediaId AND a.status=false",Long.class);
		
		disLikesQuery.setParameter("mediaId",mediaId);
		
		Long count = (long) likesQuery.getSingleResult();
		logger.info(" likes count :" +count);
		Long count1 = (long) disLikesQuery.getSingleResult();
		logger.info("dis likes count :" +count1);
		Integer likes = Math.toIntExact(count);
		Integer disLikes  = Math.toIntExact(count1);
		CountOfActionsModel result = new CountOfActionsModel(likes, disLikes);
		return result;
	}
	
	
}

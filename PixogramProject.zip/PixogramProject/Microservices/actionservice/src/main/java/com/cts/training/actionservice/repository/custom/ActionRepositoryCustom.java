package com.cts.training.actionservice.repository.custom;

import com.cts.training.actionservice.model.CountOfActionsModel;

public interface ActionRepositoryCustom {

	public CountOfActionsModel findLikesModelDislikesModelByMediaId(Integer mediaId);
}

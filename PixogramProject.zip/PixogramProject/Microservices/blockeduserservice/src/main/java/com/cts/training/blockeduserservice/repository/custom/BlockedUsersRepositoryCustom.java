package com.cts.training.blockeduserservice.repository.custom;

public interface BlockedUsersRepositoryCustom {

}

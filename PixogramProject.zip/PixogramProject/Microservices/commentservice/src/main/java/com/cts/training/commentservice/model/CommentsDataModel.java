package com.cts.training.commentservice.model;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentsDataModel {


	private Integer commentId;
	private Integer mediaId;
	private Integer userId;
	private String comments;
	private LocalDateTime createdOn;
}

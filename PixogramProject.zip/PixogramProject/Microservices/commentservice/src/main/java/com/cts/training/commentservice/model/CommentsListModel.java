package com.cts.training.commentservice.model;

import java.util.List;

import com.cts.training.commentservice.entity.Comments;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentsListModel {

	public List<Comments> commentslist;
}

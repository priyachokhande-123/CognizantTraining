package com.cts.training.commentservice.repository.custom;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.training.commentservice.model.CommentsNumberModel;


public class CommentsImpl implements CommentsRepositoryCustom {

	@Autowired
	private EntityManager em;
	
	Logger logger=LoggerFactory.getLogger(this.getClass());
	
	@Override
	public CommentsNumberModel findCountModelById(Integer mediaId) {
		TypedQuery<Long> query = em.createQuery("SELECT COUNT(*) FROM Comments c WHERE c.mediaId=:mediaId",Long.class);
		query.setParameter("commentId", mediaId);
		Long count = (long) query.getSingleResult();
		logger.info("in count of custom long :"+count);
		Integer numberOfComments = Math.toIntExact(count);
		logger.info("in count of custom int :"+numberOfComments);
		CommentsNumberModel data = new CommentsNumberModel(numberOfComments);
		return data;
	}

}

package com.cts.training.commentservice.repository.custom;

import org.springframework.stereotype.Repository;

import com.cts.training.commentservice.model.CommentsNumberModel;


public interface CommentsRepositoryCustom {

	CommentsNumberModel findCountModelById(Integer mediaId);
}

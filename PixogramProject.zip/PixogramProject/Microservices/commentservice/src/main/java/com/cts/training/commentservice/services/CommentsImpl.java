package com.cts.training.commentservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.commentservice.entity.Comments;
import com.cts.training.commentservice.model.CommentsDataModel;
import com.cts.training.commentservice.model.CommentsNumberModel;
import com.cts.training.commentservice.repository.CommentsRepository;
import com.cts.training.commentservice.repository.custom.CommentsRepositoryCustom;


@Service
public class CommentsImpl implements ICommentService{



	@Autowired
	private CommentsRepository commentsRepository;
	
	
	@Override
	public List<Comments> getall() {
		List<Comments> records = this.commentsRepository.findAll();
		return records;
	}

	@Override
	public void save(CommentsDataModel comment) {
Comments data = new Comments();
		
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		
		this.commentsRepository.save(data);
		
	
		
	}

	@Override
	public Optional<Comments> getWithId(Integer commentId) {
		Optional<Comments> record= this.commentsRepository.findById(commentId);
		return record;
		
	}

	@Override
	public void updateuser(CommentsDataModel comment) {
		Comments data = new Comments();
		data.setId(comment.getCommentId());
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		data.setCreatedOn(comment.getCreatedOn());
		this.commentsRepository.save(data);

		
	}

	@Override
	public CommentsNumberModel getCountById(Integer mediaId) {
		
		CommentsNumberModel commentsNumberModel =  this.commentsRepository.findCountModelById(mediaId);
		return commentsNumberModel;
	}
	
	
}

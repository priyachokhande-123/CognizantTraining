package com.cts.training.commentservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.training.commentservice.entity.Comments;
import com.cts.training.commentservice.model.CommentsDataModel;
import com.cts.training.commentservice.model.CommentsNumberModel;


public interface ICommentService {
	public List<Comments> getall();
	public void save(CommentsDataModel comment);
	public Optional<Comments> getWithId(Integer commentId);
	public void updateuser(CommentsDataModel action);
	public CommentsNumberModel getCountById(Integer mediaId);

}

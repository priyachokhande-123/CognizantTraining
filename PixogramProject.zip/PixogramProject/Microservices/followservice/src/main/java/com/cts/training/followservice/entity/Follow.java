package com.cts.training.followservice.entity;

import java.io.Serializable;
import java.time.LocalDateTime;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity // Registers the class as entity
//Define the mappings
@Table(name = "follow")
public class Follow implements Serializable {

	private static final long serialVersionUID = 1L;
@Id
private Integer followerId; //mineId


@Id
private Integer userId; //other


@CreationTimestamp
@Column
private LocalDateTime  createdOn;

@UpdateTimestamp
@Column
private LocalDateTime updatedOn;


}

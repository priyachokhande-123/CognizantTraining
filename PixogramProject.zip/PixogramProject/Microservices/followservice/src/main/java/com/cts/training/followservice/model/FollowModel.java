package com.cts.training.followservice.model;

import java.util.List;

import com.cts.training.followservice.entity.Follow;

public class FollowModel {

	public List<Follow> followlist;
}

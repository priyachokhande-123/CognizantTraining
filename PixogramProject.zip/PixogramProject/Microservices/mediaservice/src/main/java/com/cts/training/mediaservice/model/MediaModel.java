package com.cts.training.mediaservice.model;

import java.util.List;

import com.cts.training.mediaservice.entity.Media;

public class MediaModel {

	private List<Media> medialist;
	
}

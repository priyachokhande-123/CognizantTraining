package com.cts.training.bootapphibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootappHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}

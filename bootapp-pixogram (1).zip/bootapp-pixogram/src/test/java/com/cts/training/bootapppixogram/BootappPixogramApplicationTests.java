package com.cts.training.bootapppixogram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootappPixogramApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.cts.training.mavenweb.dao;

public class MediaDao {

}

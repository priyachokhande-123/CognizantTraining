package com.cts.training.actionservice.repository.custom;

public class ActionImpl {

}

package com.cts.training.actionservice.repository.custom;

public interface ActionRepositoryCustom {

}

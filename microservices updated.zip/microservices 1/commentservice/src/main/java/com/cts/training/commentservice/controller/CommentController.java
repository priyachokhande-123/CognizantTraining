package com.cts.training.commentservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.commentservice.entity.Comments;
import com.cts.training.commentservice.repository.CommentsRepository;




@RestController

public class CommentController {

	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		@Autowired
		private CommentsRepository commentsRepository;
		
	
		@GetMapping("/comments/{commentId}")
		public ResponseEntity<Comments> commentDetail(@PathVariable Integer commentId){
			Optional<Comments> record =  this.commentsRepository.findById(commentId);
		Comments comment=new Comments();
			if(record.isPresent()) {
				comment = record.get();
				this.logger.info("Record Found");
			}
			String port =  env.getProperty("server.port");
			this.logger.info("Media : " + comment);
	
			comment.setComment(comment.getComment()+ " (" + port + ")");
			ResponseEntity<Comments> response = new ResponseEntity<Comments>(comment, HttpStatus.OK);
			return response;
		}
	
}



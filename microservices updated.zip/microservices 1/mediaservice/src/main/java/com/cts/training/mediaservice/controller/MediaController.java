package com.cts.training.mediaservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.repository.MediaRepository;




	@RestController
	public class MediaController {

		private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		@Autowired
		private MediaRepository mediaRepository;
		
	
		@GetMapping("/media/{mediaId}")
		public ResponseEntity<Media> mediaDetail(@PathVariable Integer mediaId){
			Optional<Media> record =  this.mediaRepository.findById(mediaId);
			Media media=new Media();
			if(record.isPresent()) {
				media = record.get();
				this.logger.info("Record Found");
			}
			String port =  env.getProperty("server.port");
			this.logger.info("Media : " + media);
	
			media.setTitle(media.getTitle()+ " (" + port + ")");
			ResponseEntity<Media> response = new ResponseEntity<Media>(	media, HttpStatus.OK);
			return response;
		}
	
}

package com.cts.training.mediaservice.repository.custom;

public interface MediaRepositoryCustom {

}

package com.cts.training.newsfeedservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeedservice.repository.NewsFeedRepository;



@RestController
public class NewsFeedController {

		private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		@Autowired
		private NewsFeedRepository newsFeedRepository;
		
	
		@GetMapping("/newsfeed/{newsfeedId}")
		public ResponseEntity<NewsFeed> newsFeedDetail(@PathVariable Integer newsfeedId){
			Optional<NewsFeed> record =  this.newsFeedRepository.findById(newsfeedId);
			NewsFeed newsfeed =new NewsFeed();
			if(record.isPresent()) {
				newsfeed = record.get();
				this.logger.info("Record Found");
			}
			String port =  env.getProperty("server.port");
			this.logger.info("NewsFeed : " +newsfeed);
	
			newsfeed.setFeed(newsfeed.getFeed()+ " (" + port + ")");
			ResponseEntity<NewsFeed> response = new ResponseEntity<NewsFeed>(	newsfeed, HttpStatus.OK);
			return response;
		}
	}


